# White Raven — فروشگاه لباس زیر

یک وب‌سایت فروشگاهی کامل (تک‌فایل HTML/CSS/JS) شامل ویترین فروشگاه، سبد خرید، فرآیند تکمیل خرید و پنل مدیریت — با کاتالوگ محصولات و سفارش‌های **مشترک بین همه بازدیدکننده‌ها** (از طریق Supabase).

## فایل‌ها
```
white-raven-project/
├── index.html      ← کل سایت (فروشگاه + پنل مدیریت)
└── README.md        ← همین فایل
```

---

## مرحله ۱ — تست لوکال
فایل `index.html` را مستقیم در مرورگر باز کنید. سایت با کاتالوگ نمونه (Demo) کار می‌کند؛ چون هنوز به Supabase وصل نشده، داده‌ها فقط در همان مرورگر ذخیره می‌شوند (localStorage). این حالت برای تست کافی است، اما برای انتشار نهایی مرحله ۳ را انجام دهید.

---

## مرحله ۲ — انتشار روی GitHub Pages

1. یک ریپازیتوری جدید در GitHub بسازید (مثلاً `white-raven-shop`).
2. فایل `index.html` را در ریشه‌ی ریپازیتوری آپلود/کامیت کنید (از طریق git یا دکمه‌ی "Add file → Upload files" در گیت‌هاب).
3. به تنظیمات ریپازیتوری بروید: **Settings → Pages**.
4. زیر «Build and deployment»، گزینه‌ی **Source** را روی **Deploy from a branch** بگذارید، سپس Branch را `main` و فولدر را `/ (root)` انتخاب کنید و Save بزنید.
5. بعد از حدود یک دقیقه، سایت روی این آدرس بالا می‌آید:
   ```
   https://<your-username>.github.io/<repo-name>/
   ```

با git از خط فرمان:
```bash
git init
git add index.html README.md
git commit -m "White Raven store"
git branch -M main
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
سپس همان مرحله‌ی ۳ تا ۴ بالا (فعال‌سازی Pages) را انجام دهید.

---

## مرحله ۳ — اتصال به Supabase (برای کاتالوگ مشترک بین همه کاربران)

بدون این مرحله، هر بازدیدکننده کاتالوگ خودش را در مرورگر خودش می‌بیند (fallback به localStorage). با اتصال به Supabase، محصولات و سفارش‌هایی که در پنل مدیریت ثبت می‌کنید، برای **همه بازدیدکننده‌های سایت** یکسان خواهد بود. Supabase رایگان است و نیازی به سرور اختصاصی ندارد.

### ۳.۱ ساخت پروژه
1. به [supabase.com](https://supabase.com) بروید و یک حساب رایگان بسازید.
2. روی **New Project** بزنید، یک نام و رمز دیتابیس انتخاب کنید و منتظر بمانید تا پروژه ساخته شود (حدود ۱ دقیقه).

### ۳.۲ ساخت جدول‌ها
در پنل پروژه، به تب **SQL Editor** بروید، یک Query جدید باز کنید و این کد را اجرا کنید (دکمه Run):

```sql
-- جدول محصولات
create table products (
  id text primary key,
  name text not null,
  category text not null,
  price numeric not null default 0,
  compare_at numeric default 0,
  stock integer default 0,
  image text,
  images jsonb default '[]',
  desc text,
  sizes jsonb default '[]',
  created_at timestamptz default now()
);

-- جدول سفارش‌ها
create table orders (
  id text primary key,
  items jsonb not null,
  subtotal numeric not null,
  shipping numeric not null,
  total numeric not null,
  status text default 'در حال پردازش',
  customer text,
  created_at timestamptz default now()
);

-- جدول تنظیمات ظاهری (لوگو، تصویر صفحه نخست، فونت‌ها، اندازه‌ها) — یک ردیف ثابت با id='site'
create table settings (
  id text primary key,
  data jsonb not null default '{}',
  updated_at timestamptz default now()
);

-- دسترسی عمومی (چون سایت بدون سیستم لاگین واقعی است، این پروژه از دسترسی باز استفاده می‌کند)
alter table products enable row level security;
alter table orders enable row level security;
alter table settings enable row level security;

create policy "public read products" on products for select using (true);
create policy "public write products" on products for insert with check (true);
create policy "public update products" on products for update using (true);
create policy "public delete products" on products for delete using (true);

create policy "public read orders" on orders for select using (true);
create policy "public write orders" on orders for insert with check (true);
create policy "public update orders" on orders for update using (true);

create policy "public read settings" on settings for select using (true);
create policy "public write settings" on settings for insert with check (true);
create policy "public update settings" on settings for update using (true);
```

> اگر قبلاً (نسخه‌ی قدیمی‌تر این سایت) جدول `products` را ساخته‌اید و الان می‌خواهید امکان چند-تصویری بودن محصولات را هم داشته باشید، کافی است فقط این دو دستور را در SQL Editor اجرا کنید (بدون نیاز به ساخت دوباره‌ی جدول‌ها):
> ```sql
> alter table products add column if not exists images jsonb default '[]';
> create table if not exists settings (
>   id text primary key,
>   data jsonb not null default '{}',
>   updated_at timestamptz default now()
> );
> alter table settings enable row level security;
> create policy "public read settings" on settings for select using (true);
> create policy "public write settings" on settings for insert with check (true);
> create policy "public update settings" on settings for update using (true);
> ```

> ⚠️ این سیاست‌های دسترسی (RLS Policies) کاملاً باز هستند — یعنی هرکسی که آدرس Supabase و کلید anon شما را داشته باشد می‌تواند محصولات/سفارش‌ها را تغییر دهد. برای این پروژه که پنل مدیریت با رمز عبور خودش محافظت می‌شود قابل قبول است، اما اگر می‌خواهید امنیت بیشتری داشته باشید، بعداً باید سیستم احراز هویت واقعی Supabase (Auth) را اضافه کنید — در همین گفتگو می‌توانم کمکتان کنم.

### ۳.۳ گرفتن کلیدهای اتصال
در پنل پروژه به **Settings → API** بروید و این دو مقدار را کپی کنید:
- **Project URL** (چیزی شبیه `https://xxxxx.supabase.co`)
- **anon public key** (یک رشته‌ی طولانی)

### ۳.۴ وارد کردن کلیدها در سایت
فایل `index.html` را باز کنید، این خطوط را پیدا کنید (با جستجوی `SUPABASE_URL`):

```js
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
```

و مقادیر خودتان را جایگزین کنید:

```js
const SUPABASE_URL = 'https://xxxxx.supabase.co';
const SUPABASE_ANON_KEY = 'eyJhbGciOi...';
```

فایل را ذخیره و دوباره روی GitHub کامیت/پوش کنید. از این به بعد، هر محصول یا سفارشی که ثبت شود در Supabase ذخیره می‌شود و برای همه بازدیدکننده‌ها یکسان خواهد بود — دیگر نیازی به تنظیم دستی چیز دیگری نیست.

---

## ورود به پنل مدیریت
لینک «پنل مدیریت» پایین صفحه، یا مستقیم:
```
your-domain.com/#/admin-login
```

⚠️ رمز عبور دیگر داخل `index.html` نوشته نمی‌شود. چون این سایت یک صفحه‌ی کاملاً سمت کاربر (client-side) است، هر متنی که داخل کد HTML/JS نوشته شود — حتی رمزنگاری یا فشرده‌شده — با «مشاهده منبع صفحه» توسط هر کسی قابل خواندن است. تنها راه واقعی برای مخفی نگه‌داشتن رمز، بررسی آن روی سرور (Supabase) است، نه داخل مرورگر. برای همین، بررسی رمز پنل حالا از طریق Supabase انجام می‌شود و باید یک‌بار طبق مراحل زیر تنظیمش کنید.

### محافظت واقعی از رمز پنل مدیریت (تنظیم یک‌بار)
این کار نیاز به همان پروژه‌ی Supabase دارد که در «مرحله ۳» بالا وصل کردید (پس اول آن مرحله را انجام دهید).

۱. در Supabase به بخش **SQL Editor** بروید و کوئری زیر را اجرا کنید (این کار یک تابع می‌سازد که رمز را به‌صورت هش‌شده نگه می‌دارد و فقط نتیجه‌ی درست/غلط را برمی‌گرداند — نه خودِ رمز را):

```sql
create extension if not exists pgcrypto;

create table if not exists admin_auth (
  id int primary key default 1,
  password_hash text not null,
  constraint single_row check (id = 1)
);

-- رمز اولیه‌تان را اینجا به‌جای MY_NEW_PASSWORD بگذارید و یک‌بار اجرا کنید
insert into admin_auth (id, password_hash)
values (1, crypt('MY_NEW_PASSWORD', gen_salt('bf')))
on conflict (id) do update set password_hash = excluded.password_hash;

create or replace function verify_admin_password(input_password text)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1 from admin_auth
    where password_hash = crypt(input_password, password_hash)
  );
$$;

revoke all on admin_auth from anon, authenticated;
grant execute on function verify_admin_password(text) to anon, authenticated;
```

۲. عبارت `MY_NEW_PASSWORD` در خط `insert into admin_auth ...` را با رمز واقعی دلخواهتان جایگزین کنید، سپس فقط همان یک کوئری `insert` را اجرا کنید (تابع و جدول را دوباره نسازید).

۳. تمام — از این به بعد ورود به پنل از طریق همین تابع در Supabase بررسی می‌شود. رمز در هیچ فایلی که برای بازدیدکننده‌ها فرستاده می‌شود وجود ندارد؛ فقط نسخه‌ی هش‌شده‌اش در دیتابیس شماست.

برای عوض کردن رمز در آینده، کافیست دوباره همان کوئری `insert ... on conflict` را با رمز جدید در SQL Editor اجرا کنید — نیازی به تغییر `index.html` نیست.

> اگر هنوز Supabase را وصل نکرده‌اید، فعلاً ورود به پنل مدیریت غیرفعال می‌ماند (پیام خطا نشان داده می‌شود)، چون بدون یک بک‌اند واقعی، هیچ رمزی را نمی‌توان واقعاً امن نگه داشت.

---

## کنترل موجودی
- کاربر نمی‌تواند بیشتر از موجودی واقعی هر محصول، آن را به سبد خرید اضافه کند (چه از صفحه محصول، چه از دکمه «افزودن سریع»، چه از داخل سبد خرید).
- درست قبل از ثبت نهایی سفارش، موجودی یک‌بار دیگر از دیتابیس بررسی می‌شود (برای جلوگیری از فروش بیش از موجودی وقتی چند نفر همزمان خرید می‌کنند)؛ اگر موجودی کم‌تر شده باشد، سبد خرید خودکار بروزرسانی و به کاربر اطلاع داده می‌شود.
- به محض ثبت سفارش، موجودی محصول کم می‌شود و وقتی به صفر برسد، آن محصول خودکار در فروشگاه و در پنل مدیریت به‌صورت «ناموجود» نمایش داده می‌شود.

---

## ویژگی‌های سایت
- صفحه اصلی، دسته‌بندی زنانه/مردانه، صفحه محصول، سبد خرید، تکمیل خرید
- جستجو، فیلتر دسته‌بندی
- صفحه درباره ما / تماس با ما / حساب کاربری (نمایشی)
- پنل مدیریت: داشبورد آماری، مدیریت محصولات (افزودن/ویرایش/حذف + آپلود چند تصویر برای هر محصول)، مدیریت سفارش‌ها
- **پنل مدیریت ▸ تنظیمات ظاهری** (بخش جدید — همیشه از پنل قابل تغییر است و برای همه بازدیدکننده‌ها اعمال می‌شود):
  - آپلود/تغییر لوگوی سایت
  - آپلود/تغییر تصویر پس‌زمینه‌ی صفحه نخست (بخش Hero)
  - انتخاب فونت جداگانه برای ۶ بخش سایت (سربرگ، عنوان اصلی، عنوان بخش‌ها، متن محصولات، متن عمومی، فوتر) از بین ۱۲ فونت فارسی/انگلیسی محبوب
  - تنظیم اندازه‌ی متن هر یک از همان ۶ بخش (به‌صورت درصد، ۷۰٪ تا ۱۶۰٪)
- هر محصول می‌تواند چند تصویر داشته باشد؛ در صفحه محصول با کشیدن (drag/swipe) می‌توان بین تصاویر جابجا شد
- کلیک روی تصویر محصول آن را در یک نمای بزرگ با پس‌زمینه‌ی تار باز می‌کند؛ کلیک دوباره زوم می‌کند و با کشیدن می‌توان تصویر زوم‌شده را جابجا کرد
- کاتالوگ محصولات، سفارش‌ها و تنظیمات ظاهری مشترک بین همه کاربران (پس از اتصال Supabase)
- کاملاً واکنش‌گرا برای موبایل و دسکتاپ، راست‌به‌چپ (RTL) و فارسی

## نکته درباره‌ی سبد خرید و حساب کاربری
سبد خرید و ورود نمایشی («حساب کاربری») همچنان در همان مرورگر کاربر (localStorage) ذخیره می‌شوند — این طبیعی و درست است، چون سبد خرید باید مخصوص همان کاربر باشد، نه مشترک با بقیه.
